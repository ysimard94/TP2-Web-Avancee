<?php
class ModelVille extends Crud 
{
    protected $table = 'ville';
    protected $primaryKey = 'id';

    protected $fillable = ['id', 'nom'];
}
?>