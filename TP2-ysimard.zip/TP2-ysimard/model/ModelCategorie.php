<?php
class ModelCategorie extends Crud 
{
    protected $table = 'categorie';
    protected $primaryKey = 'id';
}
?>