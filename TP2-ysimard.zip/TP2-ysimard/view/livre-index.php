<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des livres</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
    </nav>
    <main>
        <h1>Liste des livres</h1>
        <table>
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Auteur</th>
                    <th>Nombre de pages</th>
                    <th>Catégorie</th>
                </tr>
            </thead>
            <tbody>
                {% for livre in livres %}
                    <tr>
                        <td>{{ livre.titre }}</td>
                        <td>{{ livre.auteur }}</td>
                        <td>{{ livre.nombre_pages }}</td>
                        {% for categorie in categories %}
                            {% if livre.categorie_id == categorie.id %}
                                <td>{{ categorie.nom }}</td>
                            {% endif %}
                        {% endfor %}
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    </main>
</body>
</html>