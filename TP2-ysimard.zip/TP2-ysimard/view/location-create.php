<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nouvelle location</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
    </nav>
    <main>
        <h2>Saisir une location</h2>
        <form action="{{ path }}location/store" method="post">
            <label>Client
                <select name="client_id">
                {% for client in clients %}
                    <option value="{{ client.id }}" name="{{ client.id }}">{{ client.prenom }} {{ client.nom }}</option>
                {% endfor %}
                </select>
            </label>
            <br>
            <label>Livre
                <select name="livre_id">
                {% for livre in livres %}
                    <option value="{{ livre.id }}" name="{{ livre.id }}">{{ livre.titre }}</option>
                {% endfor %}
                </select>
            </label>
            <br>
            <label>Durée de location
                <select name="datefin">
                    <option value="{{ datefin7 }}" name="datefin">1 semaine</option>
                    <option value="{{ datefin14 }}" name="datefin">2 semaines</option>
                </select>
            </label>
            <input type="hidden" name="datedebut" value="{{ datedebut }}">
            <input type="submit" value="Enregistrer" class="submit">
        </form>
    </main>
</body>
</html>