<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du client</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
    </nav>
    <main>
        <p><strong>Prénom : </strong>{{ client.prenom }}</p>
        <p><strong>Nom : </strong>{{ client.nom }}</p>
        <p><strong>Adresse : </strong>{{ client.adresse }}</p>
        <p><strong>Code Postal : </strong>{{ client.code_postal }}</p>
        <p><strong>Téléphone : </strong>{{ client.phone }}</p>
        <p><strong>Ville : </strong>
                                {% for ville in villes %}
                                    {% if client.ville_id == ville.id %}
                                    {{ ville.nom }}
                                    {% endif %}
                                {% endfor %}</p>
        <p><a href="{{ path }}client/edit/{{ client.id }}">Modifier</a></p>
    </main>
</body>
</html>