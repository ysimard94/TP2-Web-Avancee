<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des clients</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
    </nav>
    <main>
        <h1>Liste de Client </h1>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Adresse</th>
                    <th>Code Postal</th>
                    <th>Téléphone</th>
                    <th>Ville</th>
                </tr>
            </thead>
            <tbody>
                    {% for client in clients %}
                    <tr>
                        <td><a href="{{ path }}client/show/{{client.id}}">{{client.prenom}} {{client.nom}}</a></td>
                        <td>{{client.adresse}}</td>
                        <td>{{client.code_postal}}</td>
                        <td>{{client.phone}}</td>
 
                        <td>
                        {% for ville in villes %}
                            {% if client.ville_id == ville.id %}
                            {{ ville.nom }}
                            {% endif %}
                        {% endfor %}
                        </td>
                    </tr>
                    {% endfor %} 
            </tbody>
        </table>
    </main>
</body>
</html>