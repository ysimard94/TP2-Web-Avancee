<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le client</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
    </nav>
    <main>
        <h1>Modifier</h1>
        <form action="{{ path }}client/update" method="post">
            <input type="hidden" name="id" value="{{ client.id }}">
            <label>Prénom 
                <input type="text" name="prenom" value="{{ client.prenom }}">
            </label>
            <label>Nom 
                <input type="text" name="nom" value="{{ client.nom }}">
            </label>
            <label>Adresse
                <input type="text" name="adresse" value="{{ client.adresse }}">
            </label>
            <label>Code Postal
                <input type="text" name="code_postal" value="{{ client.code_postal }}">
            </label>
            <label>Ville
                <select name="ville_id">
                    {% for ville in villes %}
                            <option value="{{ ville.id }}" id="{{ ville.id }}" {% if client.ville_id == ville.id %} selected {% endif %}>{{ ville.nom }}</option>
                    {% endfor %}
                </select>
            </label>
            <input type="submit" value="Modifier" class="submit">
        </form>
        <form action="{{ path }}client/delete" method="post">
            <input type="hidden" name="id" value="{{ client.id }}">
            <input type="submit" value="Effacer" class="submit">
        </form>
    </main>
</body>
</html>