<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un client</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
    </nav>
    <main>
        <h1>Créer un client</h1>
        <form action="{{ path }}client/store" method="post">
            <label>Nom 
                <input type="text" name="nom">
            </label>
            <label>Prénom 
                <input type="text" name="prenom">
            </label>
            <label>Adresse
                <input type="text" name="adresse">
            </label>
            <label>Code Postal
                <input type="text" name="code_postal">
            </label>
            <label>Téléphone
                <input type="text" name="phone">
            </label>
            <label>Ville
                <select name="ville_id">
                {% for ville in villes %}
                    <option value="{{ ville.id }}" id="{{ ville.id }}">{{ ville.nom }}</option>
                {% endfor %}
                </select>
            </label>
            <input type="submit" value="Save" class="submit">
        </form>
    </main>
</body>
</html>