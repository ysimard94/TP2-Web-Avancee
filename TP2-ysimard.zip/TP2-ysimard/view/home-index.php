<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des locations</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
    </nav>
    <main>
        <h1>Liste des locations</h1>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Livre</th>
                    <th>Date début</th>
                    <th>Date fin</th>
                </tr>
            </thead>
            <tbody>
                {% for location in locations %}
                    <tr>
                        <td>
                        {% for client in clients %}
                            {% if location.client_id == client.id %}
                                {{ client.prenom }} {{ client.nom }}
                            {% endif %}
                        {% endfor %}
                        </td>
                        <td>
                        {% for livre in livres %}
                            {% if location.livre_id == livre.id %}
                                {{ livre.titre }}
                            {% endif %}
                        {% endfor %}
                        </td>
                        <td>{{ location.datedebut }}</td>
                        <td>{{ location.datefin }}</td>
                        <td>
                            <form action="{{ path }}location/delete" method="post">
                                <input type="hidden" name="id" value="{{ location.id }}">
                                <input type="submit" value="Effacer">
                            </form> 
                        </td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    </main>
</body>
</html>